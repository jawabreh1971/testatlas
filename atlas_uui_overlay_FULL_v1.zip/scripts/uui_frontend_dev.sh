
#!/usr/bin/env bash
set -e
cd uui
npm install
npm run dev
