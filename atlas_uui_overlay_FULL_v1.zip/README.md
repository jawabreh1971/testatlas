
# Atlas UUI Overlay (FULL) — Dockable Windows-Style UI (Blue/Copper)

Target base URL (Render): https://testatlas.onrender.com

Overlay adds:
- Frontend `uui/` (React+Vite) with dockable panels (layout-based + pop-out)
- Backend add-on `backend/app/uui/` providing `/api/uui/*`
- Scripts for VS Code
- Patcher to include router + mount UI on `/atlas-uui`

See tools/uui_apply_overlay.py and tools/uui_manual_patch.md
